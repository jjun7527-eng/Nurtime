#!/usr/bin/env bash
# Dijalankan setelah "npx cap add android": izin, ikon, suara adzan, dan ikon notifikasi.
set -euo pipefail

APP=android/app/src/main
MANIFEST="$APP/AndroidManifest.xml"

echo "==> Menambah izin Android"
python3 - "$MANIFEST" <<'PY'
import sys
p = sys.argv[1]
s = open(p, encoding="utf-8").read()
perms = [
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.USE_EXACT_ALARM",
    "android.permission.SCHEDULE_EXACT_ALARM",
    "android.permission.RECEIVE_BOOT_COMPLETED",
    "android.permission.VIBRATE",
    "android.permission.WAKE_LOCK",
    "android.permission.ACCESS_COARSE_LOCATION",
    "android.permission.ACCESS_FINE_LOCATION",
]
add = "".join(
    '    <uses-permission android:name="%s" />\n' % n
    for n in perms
    if ('android:name="%s"' % n) not in s
)
marker = "<application"
i = s.index(marker)
s = s[:i] + add.lstrip() + "\n    " + s[i:]
open(p, "w", encoding="utf-8").write(s)
print("izin ditambahkan:", add.count("uses-permission"))
PY

echo "==> Menyalin resource (ikon notifikasi, warna ikon)"
cp -r android-overrides/res/. "$APP/res/"

echo "==> Memasang suara adzan untuk channel notifikasi"
mkdir -p "$APP/res/raw"
cp www/adzan.mp3 "$APP/res/raw/adzan.mp3"

echo "==> Membuat ikon aplikasi"
make_icons() {
  local dir="$1" size="$2" fg="$3"
  local out="$APP/res/mipmap-$dir"
  mkdir -p "$out"
  convert resources/icon.png -resize "${size}x${size}" "$out/ic_launcher.png"
  cp "$out/ic_launcher.png" "$out/ic_launcher_round.png"
  convert resources/icon-maskable.png -resize "${fg}x${fg}" "$out/ic_launcher_foreground.png"
}
if command -v convert >/dev/null 2>&1; then
  make_icons mdpi 48 108
  make_icons hdpi 72 162
  make_icons xhdpi 96 216
  make_icons xxhdpi 144 324
  make_icons xxxhdpi 192 432
else
  echo "ImageMagick tidak ada: memakai ikon bawaan Capacitor."
fi

echo "==> Selesai"
