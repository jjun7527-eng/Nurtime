# NurTime APK

Proyek ini membungkus NurTime (folder `www`) menjadi aplikasi Android memakai Capacitor.
Notifikasi dan adzan dijadwalkan oleh sistem Android, jadi tetap berbunyi walau aplikasi ditutup.

## Cara paling mudah: build otomatis di GitHub (tanpa Android Studio)

1. Buat akun di https://github.com lalu buat repositori baru (boleh private), misalnya `nurtime`.
2. Unggah **seluruh isi** folder ini ke repositori, termasuk folder tersembunyi `.github`.
   - Di komputer: tarik semua file ke halaman "Upload files", atau pakai `git push`.
   - Kalau folder `.github` tidak ikut terunggah: pilih "Add file > Create new file", ketik nama
     `.github/workflows/build-apk.yml`, lalu tempel isi file dengan nama yang sama dari zip ini.
3. Buka tab **Actions**. Build jalan otomatis (sekitar 5 sampai 10 menit).
   Kalau tidak jalan sendiri: pilih "Build APK NurTime" lalu klik **Run workflow**.
4. Setelah centang hijau, buka run tersebut, turun ke bagian **Artifacts**, unduh **NurTime-apk**.
5. Ekstrak zip-nya, kirim `app-debug.apk` ke HP, lalu pasang.
   Android akan meminta izin "Pasang aplikasi tidak dikenal": izinkan untuk aplikasi file/browser yang kamu pakai.

## Setelah dipasang

1. Buka NurTime, ketuk ikon lonceng, lalu **Aktifkan Notifikasi** dan izinkan.
2. Di HP Android 12 ke bawah, kalau diminta izin "Alarm & pengingat", aktifkan.
3. Supaya adzan tidak terlewat, matikan penghemat baterai untuk NurTime
   (Pengaturan > Aplikasi > NurTime > Baterai > Tanpa batasan). Di HP Xiaomi, Oppo, Vivo, dan Samsung
   aktifkan juga "Mulai otomatis".
4. Jadwal notifikasi dibuat 10 hari ke depan setiap NurTime dibuka. Buka aplikasinya minimal
   sekali seminggu agar jadwalnya selalu terisi.

## Build di komputer sendiri (opsional)

Butuh Node 20, JDK 17, dan Android SDK (atau Android Studio).

```bash
npm install
npx cap add android
bash scripts/setup-android.sh
npx cap sync android
cd android && ./gradlew assembleDebug
# hasil: android/app/build/outputs/apk/debug/app-debug.apk
```

Setiap kali mengubah file di `www`, jalankan `npx cap sync android` lalu build ulang.

## Catatan

- APK yang dihasilkan adalah **debug build**: sudah ditandatangani otomatis dan bisa dipasang,
  tetapi belum untuk Play Store. Untuk Play Store perlu release build dengan keystore sendiri.
- Suara adzan notifikasi memakai file `www/adzan.mp3`. Ganti file itu lalu build ulang untuk mengubahnya.
  Pengaturan suara pada channel notifikasi tidak bisa diubah setelah terpasang; kalau ingin mengganti,
  copot lalu pasang ulang aplikasinya.
