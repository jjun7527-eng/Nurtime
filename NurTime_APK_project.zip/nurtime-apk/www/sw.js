// NurTime service worker: cache offline + klik notifikasi
const VERSION = "nurtime-v2.8.0";
const SHELL_CACHE = `${VERSION}-shell`;
const DATA_CACHE = `${VERSION}-data`;
const DATA_LIMIT = 300;

const SHELL = [
  "./",
  "index.html",
  "style.css",
  "script.js",
  "native.js",
  "masjid.jpg",
  "manifest.webmanifest",
  "icon-192.png",
  "icon-512.png"
];

// Hanya API ini yang disimpan untuk dipakai offline
const DATA_HOSTS = ["api.aladhan.com", "equran.id"];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(SHELL_CACHE)
      .then(cache => Promise.all(SHELL.map(url => cache.add(url).catch(() => {}))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys
          .filter(key => key !== SHELL_CACHE && key !== DATA_CACHE)
          .map(key => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

async function trimCache(cache) {
  const keys = await cache.keys();
  if (keys.length <= DATA_LIMIT) return;

  await Promise.all(keys.slice(0, keys.length - DATA_LIMIT).map(key => cache.delete(key)));
}

// Utamakan jaringan supaya selalu segar, jatuh ke cache saat offline
async function networkFirst(request, cacheName, { fallbackKey, trim } = {}) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);

  try {
    let response;

    if (cached) {
      // ada cadangan: jangan menunggu jaringan yang macet
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 6000);

      try {
        response = await fetch(request, { signal: controller.signal });
      } finally {
        clearTimeout(timer);
      }
    } else {
      response = await fetch(request);
    }

    if (response && response.ok) {
      cache.put(request, response.clone()).then(() => trim && trimCache(cache)).catch(() => {});
    }

    return response;
  } catch (error) {
    if (cached) return cached;

    if (fallbackKey) {
      const fallback = await cache.match(fallbackKey);
      if (fallback) return fallback;
    }

    throw error;
  }
}

self.addEventListener("fetch", event => {
  const request = event.request;

  if (request.method !== "GET") return;

  const url = new URL(request.url);

  if (url.origin === self.location.origin) {
    // media berukuran besar memakai Range, biarkan browser yang mengurus
    if (request.headers.has("range")) return;

    event.respondWith(
      networkFirst(request, SHELL_CACHE, {
        fallbackKey: request.mode === "navigate" ? "index.html" : undefined
      })
    );
    return;
  }

  if (DATA_HOSTS.includes(url.hostname)) {
    event.respondWith(networkFirst(request, DATA_CACHE, { trim: true }));
  }
});

self.addEventListener("notificationclick", event => {
  event.notification.close();

  event.waitUntil(
    self.clients
      .matchAll({ type: "window", includeUncontrolled: true })
      .then(list => {
        for (const client of list) {
          if ("focus" in client) return client.focus();
        }
        return self.clients.openWindow("./");
      })
  );
});
